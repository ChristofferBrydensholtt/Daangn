package com.example.skak.Controller;

import com.example.skak.Models.savedUser;
import com.example.skak.Service.loginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

@Controller
public class daangn {

    @Autowired
    com.example.skak.Service.loginService loginService ;

    @GetMapping("/")
    public String index(){
        return "daangn/index";
    }

    @GetMapping("/login")
    public String opretmedlem(){
        return "daangn/login.html";
    }

   @PostMapping("/loggedin")
    public String savedLogin(@ModelAttribute savedUser userToSave) throws IOException {
    loginService.saveUserLogin(userToSave);
        return "redirect:/";
    }



    @GetMapping("/kr/jobs")
    public String 알바(){

        return "daangn/error.html";

    }

    @GetMapping("/kr/realty")
    public String realty(){
        return "daangn/error.html";
    }

    @GetMapping("/kr/car")
    public String car(){
        return "daangn/error.html";
    }






}
