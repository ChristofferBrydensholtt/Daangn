package com.example.skak.Service;

import com.example.skak.Models.savedUser;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.IOException;

@Service
public class loginService {





    public void saveUserLogin(savedUser user) throws IOException {



        FileWriter fw = new FileWriter("src/savedAccounts.txt", true);
        fw.write("Email: " + " " + user.getEmail() + " - Password: " + user.getPassword() + "\n");

        fw.close();




    }




}
