package com.example.skak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkakApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkakApplication.class, args);
    }

}
